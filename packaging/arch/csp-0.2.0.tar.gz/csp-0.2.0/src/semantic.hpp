#pragma once
#include "ast.hpp"
#include "diagnostic.hpp"
#include <unordered_map>
#include <vector>

namespace csp {
class SemanticAnalyzer {
  DiagnosticEngine &diagnostics_;
  std::vector<std::unordered_map<std::string, std::vector<const Node *>>> scopes_;
  std::unordered_map<std::string, Location> labels_;
  std::vector<std::pair<std::string, Location>> gotos_;
  unsigned function_depth_ = 0;
  unsigned loop_depth_ = 0;
  unsigned switch_depth_ = 0;
  std::vector<bool> switch_has_default_;
  void visit(const Node &node);
  void visit_children(const Node &node);
  void enter_scope();
  void leave_scope();
  void declare_name(const std::string &name, const Node &node,
                    bool allow_overload = false);
  void visit_callable(const Node &node);
  void validate_gotos();
  static std::string declaration_name(const std::string &text);
  static std::string function_signature(const Node &node);
  static bool has_body(const Node &node);

public:
  explicit SemanticAnalyzer(DiagnosticEngine &diagnostics)
      : diagnostics_(diagnostics) {}
  bool analyze(const Node &program);
};
} // namespace csp
