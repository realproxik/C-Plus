#include "semantic.hpp"
#include <cctype>
#include <sstream>

namespace csp {
void SemanticAnalyzer::enter_scope() { scopes_.emplace_back(); }
void SemanticAnalyzer::leave_scope() {
  if (!scopes_.empty())
    scopes_.pop_back();
}

std::string SemanticAnalyzer::declaration_name(const std::string &text) {
  std::size_t end = text.find_first_of("=([{;|");
  if (end == std::string::npos)
    end = text.size();
  while (end && std::isspace(static_cast<unsigned char>(text[end - 1])))
    --end;
  std::size_t begin = end;
  while (begin && (std::isalnum(static_cast<unsigned char>(text[begin - 1])) ||
                   text[begin - 1] == '_'))
    --begin;
  return text.substr(begin, end - begin);
}

namespace {
std::string trim(std::string value) {
  while (!value.empty() &&
         std::isspace(static_cast<unsigned char>(value.front())))
    value.erase(value.begin());
  while (!value.empty() &&
         std::isspace(static_cast<unsigned char>(value.back())))
    value.pop_back();
  return value;
}

std::string parameter_type(std::string value) {
  if (const auto equals = value.find('='); equals != std::string::npos)
    value.resize(equals);
  value = trim(std::move(value));
  std::size_t end = value.size();
  while (end && std::isspace(static_cast<unsigned char>(value[end - 1])))
    --end;
  std::size_t begin = end;
  while (begin &&
         (std::isalnum(static_cast<unsigned char>(value[begin - 1])) ||
          value[begin - 1] == '_'))
    --begin;
  if (begin > 0 && begin < end)
    value.resize(begin);
  return trim(std::move(value));
}
} // namespace

bool SemanticAnalyzer::has_body(const Node &node) {
  for (const auto &child : node.children)
    if (child->kind == NodeKind::Block)
      return true;
  return false;
}

std::string SemanticAnalyzer::function_signature(const Node &node) {
  std::string result = declaration_name(node.value) + "(";
  bool first = true;
  for (const auto &child : node.children) {
    if (child->kind != NodeKind::Parameter)
      continue;
    if (!first)
      result += ',';
    result += parameter_type(child->value);
    first = false;
  }
  result += ')';
  if (const auto suffix = node.value.find('|'); suffix != std::string::npos)
    result += trim(node.value.substr(suffix));
  return result;
}

void SemanticAnalyzer::declare_name(const std::string &name, const Node &node,
                                    bool allow_overload) {
  if (name.empty() || scopes_.empty())
    return;
  auto &entries = scopes_.back()[name];
  if (entries.empty()) {
    entries.push_back(&node);
    return;
  }
  if (allow_overload && node.kind == NodeKind::Function) {
    const std::string signature = function_signature(node);
    bool functions_only = true;
    bool matching_signature = false;
    bool existing_definition = false;
    for (const Node *existing : entries) {
      functions_only &= existing->kind == NodeKind::Function;
      if (existing->kind == NodeKind::Function &&
          function_signature(*existing) == signature) {
        matching_signature = true;
        existing_definition |= has_body(*existing);
      }
    }
    if (functions_only) {
      if (matching_signature && existing_definition && has_body(node)) {
        const Node *previous = nullptr;
        for (const Node *existing : entries)
          if (function_signature(*existing) == signature &&
              has_body(*existing)) {
            previous = existing;
            break;
          }
        auto &diagnostic = diagnostics_.error(
            node.location, "redefinition of function '" + signature + "'");
        if (previous)
          diagnostic.notes.push_back(
              "previous definition is at line " +
              std::to_string(previous->location.line));
      }
      entries.push_back(&node);
      return;
    }
  }
  {
    auto &diagnostic =
        diagnostics_.error(node.location, "redeclaration of '" + name + "'");
    diagnostic.notes.push_back("previous declaration is at line " +
                               std::to_string(entries.front()->location.line));
  }
}

void SemanticAnalyzer::validate_gotos() {
  for (const auto &[target, location] : gotos_)
    if (!target.empty() && labels_.find(target) == labels_.end())
      diagnostics_.error(location,
                         "goto targets unknown label '" + target + "'");
}

void SemanticAnalyzer::visit_callable(const Node &node) {
  auto outer_labels = std::move(labels_);
  auto outer_gotos = std::move(gotos_);
  const unsigned outer_loops = loop_depth_;
  const unsigned outer_switches = switch_depth_;
  auto outer_defaults = std::move(switch_has_default_);
  labels_.clear();
  gotos_.clear();
  loop_depth_ = 0;
  switch_depth_ = 0;
  switch_has_default_.clear();
  ++function_depth_;
  enter_scope();
  visit_children(node);
  leave_scope();
  --function_depth_;
  validate_gotos();
  labels_ = std::move(outer_labels);
  gotos_ = std::move(outer_gotos);
  loop_depth_ = outer_loops;
  switch_depth_ = outer_switches;
  switch_has_default_ = std::move(outer_defaults);
}

void SemanticAnalyzer::visit_children(const Node &node) {
  for (const auto &child : node.children)
    visit(*child);
}

void SemanticAnalyzer::visit(const Node &node) {
  switch (node.kind) {
  case NodeKind::Program:
  case NodeKind::Namespace:
  case NodeKind::Class:
  case NodeKind::Struct:
  case NodeKind::Union:
  case NodeKind::Block:
    enter_scope();
    visit_children(node);
    leave_scope();
    break;
  case NodeKind::Function:
    declare_name(declaration_name(node.value), node, true);
    visit_callable(node);
    break;
  case NodeKind::LambdaExpression:
    visit_callable(node);
    break;
  case NodeKind::Declaration:
    declare_name(declaration_name(node.value), node);
    visit_children(node);
    break;
  case NodeKind::Label:
    if (function_depth_ &&
        !labels_.emplace(node.value, node.location).second)
      diagnostics_.error(node.location, "duplicate label '" + node.value + "'");
    break;
  case NodeKind::Goto:
    if (!function_depth_)
      diagnostics_.error(node.location, "goto is only valid inside a function");
    else
      gotos_.emplace_back(declaration_name(node.value), node.location);
    break;
  case NodeKind::For:
  case NodeKind::RangeFor:
  case NodeKind::While:
  case NodeKind::DoWhile:
    ++loop_depth_;
    visit_children(node);
    --loop_depth_;
    break;
  case NodeKind::Switch:
    ++switch_depth_;
    switch_has_default_.push_back(false);
    visit_children(node);
    switch_has_default_.pop_back();
    --switch_depth_;
    break;
  case NodeKind::Case:
    if (!switch_depth_)
      diagnostics_.error(node.location, "case is only valid inside a switch");
    visit_children(node);
    break;
  case NodeKind::Default:
    if (!switch_depth_) {
      diagnostics_.error(node.location,
                         "default is only valid inside a switch");
    } else if (switch_has_default_.back()) {
      diagnostics_.error(node.location,
                         "switch cannot contain more than one default label");
    } else {
      switch_has_default_.back() = true;
    }
    break;
  case NodeKind::Break:
    if (!loop_depth_ && !switch_depth_)
      diagnostics_.error(node.location,
                         "break is only valid inside a loop or switch");
    break;
  case NodeKind::Continue:
    if (!loop_depth_)
      diagnostics_.error(node.location, "continue is only valid inside a loop");
    break;
  case NodeKind::Return:
  case NodeKind::CoroutineReturn:
  case NodeKind::CoroutineYield:
    if (!function_depth_)
      diagnostics_.error(node.location,
                         "return is only valid inside a function");
    visit_children(node);
    break;
  case NodeKind::Throw:
    if (!function_depth_)
      diagnostics_.error(node.location, "throw is only valid inside a function");
    visit_children(node);
    break;
  case NodeKind::KernelLaunchExpression:
    if (node.children.size() < 3)
      diagnostics_.error(node.location,
                         "kernel launch requires grid and block dimensions");
    visit_children(node);
    break;
  default:
    visit_children(node);
    break;
  }
}

bool SemanticAnalyzer::analyze(const Node &program) {
  scopes_.clear();
  labels_.clear();
  gotos_.clear();
  switch_has_default_.clear();
  visit(program);
  validate_gotos();
  return !diagnostics_.has_errors();
}
} // namespace csp
