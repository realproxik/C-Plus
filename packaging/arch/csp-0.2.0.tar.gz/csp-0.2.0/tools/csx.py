#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def registry_path() -> Path:
    candidates = [
        Path(os.environ["CSX_REGISTRY"]) if "CSX_REGISTRY" in os.environ else None,
        ROOT / "packages" / "csx" / "index.json",
        ROOT / "share" / "csx" / "index.json",
        Path(sys.prefix) / "share" / "csx" / "index.json",
    ]
    for candidate in candidates:
        if candidate and candidate.is_file():
            return candidate
    raise FileNotFoundError("cannot find CSX registry; set CSX_REGISTRY to index.json")


def load_registry() -> dict:
    return json.loads(registry_path().read_text(encoding="utf-8"))


def packages_by_name(registry: dict) -> dict:
    return {item["name"]: item for item in registry["packages"]}


def resolve(names: list[str], packages: dict, selected: set[str] | None = None) -> list[dict]:
    selected = selected or set()
    result = []
    for name in names:
        if name in selected:
            continue
        if name not in packages:
            raise ValueError(f"unknown package: {name}")
        selected.add(name)
        result.extend(resolve(packages[name].get("depends", []), packages, selected))
        result.append(packages[name])
    return result


def header_names(item: dict) -> list[str]:
    names = list(item.get("headers", []))
    pattern = item.get("header_glob")
    if pattern:
        names.extend(path.relative_to(ROOT / "include").as_posix() for path in (ROOT / "include").glob(pattern) if path.is_file())
    for name in names:
        path = Path(name)
        if path.is_absolute() or ".." in path.parts:
            raise ValueError(f"unsafe header path in registry: {name}")
    return sorted(set(names))


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def state_path(prefix: Path) -> Path:
    return prefix / ".csx-state.json"


def read_state(prefix: Path) -> dict:
    path = state_path(prefix)
    return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {"packages": {}}


def write_state(prefix: Path, state: dict) -> None:
    prefix.mkdir(parents=True, exist_ok=True)
    temporary = prefix / ".csx-state.json.tmp"
    temporary.write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")
    temporary.replace(state_path(prefix))


def main() -> int:
    parser = argparse.ArgumentParser(prog="csx", description="C+ package manager")
    parser.add_argument("--prefix", type=Path, default=Path.home() / ".csx", help="installation prefix")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("list", help="list available packages")
    installed = sub.add_parser("installed", help="list installed packages")
    installed.add_argument("--prefix", type=Path, default=argparse.SUPPRESS, help="installation prefix")
    verify = sub.add_parser("verify", help="verify installed header checksums")
    verify.add_argument("--prefix", type=Path, default=argparse.SUPPRESS, help="installation prefix")
    search = sub.add_parser("search", help="search package names and descriptions")
    search.add_argument("query")
    info = sub.add_parser("info", help="show package metadata")
    info.add_argument("name")
    install = sub.add_parser("install", help="install packages and dependencies")
    install.add_argument("--prefix", type=Path, default=argparse.SUPPRESS, help="installation prefix")
    install.add_argument("names", nargs="+")
    remove = sub.add_parser("remove", help="remove a package's headers")
    remove.add_argument("--prefix", type=Path, default=argparse.SUPPRESS, help="installation prefix")
    remove.add_argument("names", nargs="+")
    args = parser.parse_args()
    try:
        registry = load_registry()
    except (OSError, json.JSONDecodeError) as error:
        print(f"csx: cannot load registry: {error}", file=sys.stderr)
        return 1
    packages = packages_by_name(registry)

    if args.command == "list":
        for item in registry["packages"]:
            print(f"{item['name']} {item['version']}  {item['description']}")
        return 0
    if args.command in {"installed", "verify"}:
        state = read_state(args.prefix)
        if args.command == "installed":
            for name, item in sorted(state["packages"].items()):
                print(f"{name} {item['version']}")
            return 0
        failures = 0
        for name, item in sorted(state["packages"].items()):
            for header, expected in item.get("files", {}).items():
                path = args.prefix / "include" / header
                if not path.is_file() or digest(path) != expected:
                    print(f"FAILED {name}: {header}")
                    failures += 1
        print("all installed headers verified" if not failures else f"{failures} header(s) failed verification")
        return bool(failures)
    if args.command in {"search", "info"}:
        if args.command == "search":
            query = args.query.lower()
            for item in registry["packages"]:
                if query in f"{item['name']} {item['description']}".lower():
                    print(f"{item['name']} {item['version']}  {item['description']}")
            return 0
        item = packages.get(args.name)
        if not item:
            print(f"csx: unknown package: {args.name}", file=sys.stderr)
            return 1
        print(json.dumps(item, indent=2))
        return 0

    try:
        selected = resolve(args.names, packages) if args.command == "install" else [packages[name] for name in args.names]
    except (KeyError, ValueError) as error:
        name = error.args[0] if isinstance(error, KeyError) else error
        print(f"csx: unknown package: {name}", file=sys.stderr)
        return 1
    include = args.prefix / "include"
    if args.command == "install":
        state = read_state(args.prefix)
        for item in selected:
            installed_files = {}
            headers = header_names(item)
            for header in headers:
                source = ROOT / "include" / header
                destination = include / header
                if not source.exists():
                    print(f"csx: missing registry header: {header}", file=sys.stderr)
                    return 1
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, destination)
                installed_files[header] = digest(destination)
            state["packages"][item["name"]] = {"version": item["version"], "files": installed_files}
            print(f"installed {item['name']} {item['version']}")
        write_state(args.prefix, state)
        return 0
    state = read_state(args.prefix)
    requested = {item["name"] for item in selected}
    blocked = []
    for installed_name in state["packages"]:
        installed_item = packages.get(installed_name, {})
        for dependency in installed_item.get("depends", []):
            if dependency in requested and installed_name not in requested:
                blocked.append(f"{dependency} is required by {installed_name}")
    if blocked:
        print("csx: refusing removal: " + "; ".join(blocked), file=sys.stderr)
        return 1
    for item in selected:
        headers = state["packages"].get(item["name"], {}).get("files", {}).keys()
        for header in headers:
            destination = include / header
            if destination.exists():
                destination.unlink()
                print(f"removed {header}")
        state["packages"].pop(item["name"], None)
    write_state(args.prefix, state)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
