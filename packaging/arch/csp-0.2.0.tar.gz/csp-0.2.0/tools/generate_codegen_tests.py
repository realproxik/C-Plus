#!/usr/bin/env python3
"""Generate the checked-in CSP architecture/code-generation regression corpus."""
from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CASES = ROOT / "tests" / "codegen" / "cases"

NAMES = """
aarch64-arm-load-store aarch64-pointer-auth aarch64-vld2-s16 aarch64-xray
align_offset bpf-more-than-five-args bpf_unaligned breakpoint carryless-mul
closure-inherit-target-feature cmse-clear-padding cmse cstring-merging
debuginfo-for-profiling dwarf-mixed-versions-lto dwarf4 dwarf5 emit-intel-att-syntax
fentry force-target-feature indexing-with-bools-no-redundant-instructions is_aligned
issue-141649 issue-83585-small-pod-struct-equality large_data_threshold
loongarch-float-struct-abi manual-eq-efficient mips-div-no-trap mips-struct-float
niche-prefer-zero nvptx-arch-default nvptx-arch-emit-asm nvptx-arch-target-cpu
nvptx-atomics nvptx-c-abi-arg-v7 nvptx-c-abi-ret-v7 nvptx-debug
nvptx-internalizing nvptx-linking-binary nvptx-linking-cdylib nvptx-safe-naming
panic-no-unwind-no-uwtable panic-unwind-no-uwtable pauth-basic pic-relocation-model
pie-relocation-model powerpc64-struct-abi reg-struct-return regparm-module-flag
riscv-float-struct-abi riscv-soft-abi-with-float-features rust-abi-arg-attr
s390x-backchain-toggle s390x-packedstack-toggle s390x-softfloat-abi s390x-vector-abi
simd-bitmask simd-intrinsic-gather simd-intrinsic-mask-load simd-intrinsic-mask-reduce
simd-intrinsic-mask-store simd-intrinsic-scatter simd-intrinsic-select slice-is-ascii
slice-is_ascii slp-vectorize-closure small_data_threshold sparc-struct-abi stack-probes
static-relocation-model strict_provenance tail-call-indirect tail-call-infinite-recursion
target-feature-multiple wasm_exceptions wasm_legacy_eh x86-return-float
x86_64-array-pair-load-store-merge x86_64-bigint-helpers x86_64-cmp
x86_64-floating-point-clamp x86_64-fortanix-unknown-sgx-lvi-generic-load
x86_64-fortanix-unknown-sgx-lvi-generic-ret
x86_64-fortanix-unknown-sgx-lvi-inline-assembly x86_64-function-return
x86_64-indirect-branch-cs-prefix x86_64-mcount x86_64-no-jump-tables x86_64-sse_crc
x86_64-typed-swap x86_64-windows-float-abi x86_64-windows-i128-abi x86_64-xray
""".split()

DIRECTORIES = [
    "aarch64", "asm", "auxiliary", "c-variadic", "compiletest-self-test",
    "libs", "naked-functions", "nvptx-kernel-abi", "sanitizer", "simd",
    "stack-protector", "targets",
]

TOTAL_CASES = 5094
TOTAL_FOLDERS = 85
MATRIX_FOLDERS = TOTAL_FOLDERS - len(DIRECTORIES)
MATRIX_KINDS = ["integer", "array", "structure", "floating", "string", "pointer", "recursion"]
MATRIX_TARGETS = [
    "host", "aarch64-none-elf", "riscv64-unknown-linux-gnu",
    "wasm32-unknown-unknown", "powerpc64le-unknown-linux-gnu",
    "s390x-unknown-linux-gnu", "sparc64-unknown-linux-gnu",
    "loongarch64-unknown-linux-gnu", "mips64-unknown-linux-gnuabi64",
    "bpfel-unknown-none", "nvptx64-nvidia-cuda",
]


def target_for(name: str) -> str:
    rules = [
        (("aarch64", "cmse", "pauth"), "aarch64-none-elf"),
        (("bpf",), "bpfel-unknown-none"), (("nvptx",), "nvptx64-nvidia-cuda"),
        (("loongarch",), "loongarch64-unknown-linux-gnu"),
        (("mips",), "mips64-unknown-linux-gnuabi64"),
        (("powerpc",), "powerpc64le-unknown-linux-gnu"),
        (("riscv",), "riscv64-unknown-linux-gnu"),
        (("s390x",), "s390x-unknown-linux-gnu"),
        (("sparc",), "sparc64-unknown-linux-gnu"),
        (("wasm",), "wasm32-unknown-unknown"),
    ]
    for prefixes, target in rules:
        if name.startswith(prefixes):
            return target
    return "host"


def kind_for(name: str) -> str:
    if "tail-call" in name:
        return "recursion"
    if any(word in name for word in ("simd", "slice", "load-store", "vld2", "array-pair", "gather", "scatter")):
        return "array"
    if any(word in name for word in ("struct", "abi-arg", "abi-ret", "pod-struct", "function-return")):
        return "structure"
    if any(word in name for word in ("float", "clamp")):
        return "floating"
    if "cstring" in name or "ascii" in name:
        return "string"
    if any(word in name for word in ("aligned", "offset", "provenance", "unaligned")):
        return "pointer"
    return "integer"


def source_for(name: str, target: str, kind: str, variant: int = 0) -> str:
    symbol = "csp_test_" + re.sub(r"[^a-zA-Z0-9_]", "_", name)
    heading = f"// CSP-CODEGEN: name={name} target={target} kind={kind}\n"
    if kind == "array":
        multiplier = 2 + variant % 13
        increment = 1 + variant % 17
        body = f"""int {symbol}(int *output, const int *input, int count) {{
    int checksum = 0;
    for (int index = 0; index < count; ++index) {{
        int value = input[index] * {multiplier} + {increment};
        output[index] = value;
        checksum ^= value;
    }}
    return checksum;
}}

int main() {{
    int input[8] = {{1, 2, 3, 4, 5, 6, 7, 8}};
    int output[8] = {{0}};
    return {symbol}(output, input, 8) == 0;
}}
"""
    elif kind == "structure":
        delta = 1 + variant % 11
        body = f"""struct {symbol}_pair {{ double left; double right; }};

{symbol}_pair {symbol}({symbol}_pair value) {{
    return {{value.right + {delta}.0, value.left - {delta}.0}};
}}

int main() {{
    {symbol}_pair value = {symbol}({{4.0, 9.0}});
    return value.left > value.right ? 0 : 1;
}}
"""
    elif kind == "floating":
        numerator = 2 + variant % 7
        body = f"""double {symbol}(double value, double low, double high) {{
    if (value < low) return low;
    if (value > high) return high;
    return value * {numerator}.0;
}}

int main() {{ return {symbol}(4.0, 0.0, 10.0) > 0.0 ? 0 : 1; }}
"""
    elif kind == "string":
        body = f"""int {symbol}(const char *text) {{
    int checksum = 0;
    for (int index = 0; text[index] != '\\0'; ++index) checksum += text[index];
    return checksum;
}}

int main() {{ return {symbol}("CSP-codegen") == 0; }}
"""
    elif kind == "pointer":
        body = f"""unsigned long long {symbol}(const unsigned char *data, int count) {{
    unsigned long long value = 1469598103934665603ULL;
    for (int index = 0; index < count; ++index) value = (value ^ data[index]) * 1099511628211ULL;
    return value;
}}

int main() {{ unsigned char data[5] = {{1, 3, 5, 7, 9}}; return {symbol}(data, 5) == 0; }}
"""
    elif kind == "recursion":
        body = f"""int {symbol}(int value, int accumulator) {{
    if (value <= 0) return accumulator;
    return {symbol}(value - 1, accumulator + value);
}}

int main() {{ return {symbol}(10, 0) == 55 ? 0 : 1; }}
"""
    else:
        first_shift = 7 + variant % 17
        second_shift = 19 + variant % 23
        body = f"""unsigned long long {symbol}(unsigned long long value) {{
    value ^= value >> {first_shift};
    value *= 0xff51afd7ed558ccdULL;
    value ^= value >> {second_shift};
    return value;
}}

int main() {{ return {symbol}(0x12345678ULL) == 0; }}
"""
    return heading + "// Generated from the CSP code-generation manifest; edit the generator, not this file.\n\n" + body


def main() -> None:
    CASES.mkdir(parents=True, exist_ok=True)
    manifest = []
    for name in NAMES:
        target, kind = target_for(name), kind_for(name)
        relative = f"cases/{name}.csp"
        (CASES / f"{name}.csp").write_text(source_for(name, target, kind), encoding="utf-8")
        manifest.append({"name": name, "file": relative, "target": target, "kind": kind, "origin": "supplied"})
    for directory in DIRECTORIES:
        path = CASES / directory
        path.mkdir(parents=True, exist_ok=True)
        (path / "README.md").write_text(
            f"# {directory}\n\nCSP code-generation cases for the `{directory}` category.\n",
            encoding="utf-8",
        )
        smoke_name = f"category-{directory}"
        smoke_file = f"cases/{directory}/smoke.csp"
        (path / "smoke.csp").write_text(source_for(smoke_name, "host", "integer", len(manifest)), encoding="utf-8")
        manifest.append({"name": smoke_name, "file": smoke_file, "target": "host", "kind": "integer", "origin": "category"})
    matrix_count = TOTAL_CASES - len(manifest)
    for index in range(matrix_count):
        folder = f"matrix-{index % MATRIX_FOLDERS:03d}"
        path = CASES / folder
        path.mkdir(parents=True, exist_ok=True)
        kind = MATRIX_KINDS[index % len(MATRIX_KINDS)]
        target = MATRIX_TARGETS[(index // len(MATRIX_KINDS)) % len(MATRIX_TARGETS)]
        name = f"matrix-{index:04d}-{kind}"
        relative = f"cases/{folder}/{name}.csp"
        (path / f"{name}.csp").write_text(source_for(name, target, kind, index + 1000), encoding="utf-8")
        manifest.append({"name": name, "file": relative, "target": target, "kind": kind, "origin": "matrix", "variant": index})
    if len(manifest) != TOTAL_CASES:
        raise RuntimeError(f"generated {len(manifest)} cases, expected {TOTAL_CASES}")
    output = ROOT / "tests" / "codegen" / "manifest.json"
    output.write_text(json.dumps({"format": 1, "cases": manifest}, indent=2) + "\n", encoding="utf-8")
    print(f"generated {len(manifest)} CSP cases across {TOTAL_FOLDERS} folders")


if __name__ == "__main__":
    main()
