#!/usr/bin/env python3
"""Build and measure equivalent C+, C, C++, and Rust integer workloads."""
from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import statistics
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / "benchmarks"
BUILD = HERE / "build"
WEB_ASSETS = ROOT / "website" / "assets"


def found(*names: str) -> str | None:
    for name in names:
        path = shutil.which(name)
        if path:
            return path
    return None


def version(command: str) -> str:
    process = subprocess.run([command, "--version"], text=True, capture_output=True, check=False)
    text = (process.stdout or process.stderr).splitlines()
    return text[0].strip() if text else "unknown version"


def executable(name: str) -> Path:
    return BUILD / (name + (".exe" if os.name == "nt" else ""))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=int, default=7, help="timed samples per language")
    parser.add_argument("--warmup", type=int, default=2, help="untimed warm-up runs")
    parser.add_argument("--rounds", type=int, default=25_000_000, help="workload iterations")
    parser.add_argument("--no-web", action="store_true", help="do not refresh website benchmark data")
    args = parser.parse_args()
    if args.runs < 1 or args.warmup < 0 or args.rounds < 1:
        parser.error("runs and rounds must be positive; warmup cannot be negative")

    BUILD.mkdir(parents=True, exist_ok=True)
    cspc = ROOT / ("cspc.exe" if os.name == "nt" else "cspc")
    cc, cxx, rustc = found("gcc", "clang"), found("g++", "clang++"), found("rustc")
    candidates = [
        ("C+", str(cspc) if cspc.exists() and cxx else None,
         [str(cspc), str(HERE / "workload.csp"), "--no-runtime", "--compiler", str(cxx or "g++"), "-O3", "-o", str(executable("workload-csp"))], executable("workload-csp")),
        ("C", cc, [str(cc or "gcc"), "-std=c17", "-O3", str(HERE / "workload.c"), "-o", str(executable("workload-c"))], executable("workload-c")),
        ("C++", cxx, [str(cxx or "g++"), "-std=c++20", "-O3", str(HERE / "workload.cpp"), "-o", str(executable("workload-cpp"))], executable("workload-cpp")),
        ("Rust", rustc, [str(rustc or "rustc"), "-C", "opt-level=3", str(HERE / "workload.rs"), "-o", str(executable("workload-rust"))], executable("workload-rust")),
    ]

    results: list[dict] = []
    expected: str | None = None
    for language, compiler, command, output in candidates:
        if not compiler:
            results.append({"language": language, "status": "not installed"})
            continue
        started = time.perf_counter()
        build = subprocess.run(command, cwd=ROOT, text=True, capture_output=True, check=False)
        compile_ms = (time.perf_counter() - started) * 1000
        if build.returncode != 0:
            results.append({"language": language, "status": "build failed", "error": (build.stderr or build.stdout)[-2000:]})
            continue
        run_command = [str(output), str(args.rounds)]
        for _ in range(args.warmup):
            subprocess.run(run_command, capture_output=True, check=True)
        samples = []
        checksum = ""
        for _ in range(args.runs):
            started = time.perf_counter_ns()
            run = subprocess.run(run_command, text=True, capture_output=True, check=True)
            samples.append((time.perf_counter_ns() - started) / 1_000_000)
            checksum = run.stdout.strip()
        expected = checksum if expected is None else expected
        status = "ok" if checksum == expected else "checksum mismatch"
        compiler_version = version(str(cspc)) + " via " + version(str(cxx)) if language == "C+" else version(str(compiler))
        results.append({
            "language": language, "status": status, "compiler": compiler_version,
            "compile_ms": round(compile_ms, 3), "median_ms": round(statistics.median(samples), 3),
            "min_ms": round(min(samples), 3), "max_ms": round(max(samples), 3),
            "binary_bytes": output.stat().st_size, "checksum": checksum,
            "samples_ms": [round(value, 3) for value in samples], "command": command,
        })

    payload = {
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "machine": {"os": platform.platform(), "cpu": platform.processor() or os.environ.get("PROCESSOR_IDENTIFIER", "unknown"), "python": platform.python_version()},
        "method": {"workload": "xorshift64* integer mixing", "rounds": args.rounds, "runs": args.runs, "warmup": args.warmup, "optimization": "release / level 3", "timer": "wall clock including process startup"},
        "results": results,
    }
    json_path = HERE / "results.json"
    json_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    if not args.no_web:
        WEB_ASSETS.mkdir(parents=True, exist_ok=True)
        (WEB_ASSETS / "benchmarks.js").write_text("window.CSP_BENCHMARK_DATA = " + json.dumps(payload, indent=2) + ";\n", encoding="utf-8")

    print(f"{'Language':<9} {'Runtime median':>15} {'min':>10} {'max':>10} {'compile':>11} {'bytes':>11}")
    for item in results:
        if item["status"] != "ok":
            print(f"{item['language']:<9} {item['status']:>15}")
        else:
            print(f"{item['language']:<9} {item['median_ms']:>12.3f} ms {item['min_ms']:>7.3f} ms {item['max_ms']:>7.3f} ms {item['compile_ms']:>8.3f} ms {item['binary_bytes']:>11}")
    print(f"\nRaw data: {json_path}")
    return 1 if any(item["status"] not in {"ok", "not installed"} for item in results) else 0


if __name__ == "__main__":
    raise SystemExit(main())
