#!/usr/bin/env python3
"""Validate, frontend-check, and optionally assembly-compile CSP codegen cases."""
from __future__ import annotations

import argparse
import concurrent.futures
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SUITE = ROOT / "tests" / "codegen"
MANIFEST = SUITE / "manifest.json"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--validate-only", action="store_true")
    parser.add_argument("--compile-host", action="store_true", help="emit optimized assembly for host cases")
    parser.add_argument("--limit", type=int, default=0, help="limit checked cases; zero checks all")
    parser.add_argument("--jobs", type=int, default=min(8, os.cpu_count() or 1), help="parallel compiler processes")
    parser.add_argument("--shard", default="", metavar="INDEX/TOTAL", help="run one 1-based CI shard")
    parser.add_argument("--quiet", action="store_true", help="only print failures and final totals")
    args = parser.parse_args()
    payload = json.loads(MANIFEST.read_text(encoding="utf-8"))
    cases = payload.get("cases", [])
    expected_names = set()
    errors = []
    for case in cases:
        path = SUITE / case["file"]
        expected_names.add(path.resolve())
        if not path.is_file():
            errors.append(f"missing: {path}")
            continue
        source = path.read_text(encoding="utf-8")
        marker = f"name={case['name']} target={case['target']} kind={case['kind']}"
        if marker not in source or "int main()" not in source or len(source.splitlines()) < 8:
            errors.append(f"invalid or placeholder case: {path}")
    actual_names = {path.resolve() for path in (SUITE / "cases").rglob("*.csp")}
    for extra in sorted(actual_names - expected_names):
        errors.append(f"unregistered case: {extra}")
    if errors:
        print("\n".join(errors), file=sys.stderr)
        return 1
    if args.validate_only:
        folders = {Path(case["file"]).parts[1] for case in cases if len(Path(case["file"]).parts) > 2}
        print(f"validated {len(cases)} CSP code-generation cases across {len(folders)} case folders")
        return 0

    compiler = ROOT / ("cspc.exe" if sys.platform == "win32" else "cspc")
    if not compiler.is_file():
        print(f"missing compiler: {compiler}", file=sys.stderr)
        return 1
    selected = cases
    if args.shard:
        try:
            shard_index, shard_total = (int(value) for value in args.shard.split("/", 1))
            if shard_index < 1 or shard_index > shard_total or shard_total < 1:
                raise ValueError
        except ValueError:
            parser.error("--shard must be INDEX/TOTAL with 1 <= INDEX <= TOTAL")
        selected = [case for index, case in enumerate(selected) if index % shard_total == shard_index - 1]
    if args.limit:
        selected = selected[:args.limit]

    def check_case(case: dict) -> tuple[dict, str]:
        source = SUITE / case["file"]
        check = subprocess.run([str(compiler), str(source), "--check"], cwd=ROOT,
                               text=True, capture_output=True)
        if check.returncode:
            return case, check.stderr or check.stdout
        if args.compile_host and case["target"] == "host":
            output = SUITE / "build" / f"{case['name']}.s"
            output.parent.mkdir(parents=True, exist_ok=True)
            emit = subprocess.run([str(compiler), str(source), "--no-runtime", "-S", "-O3", "-o", str(output)],
                                  cwd=ROOT, text=True, capture_output=True)
            if emit.returncode or not output.is_file() or output.stat().st_size == 0:
                return case, "assembly emission failed\n" + (emit.stderr or emit.stdout)
        return case, ""

    completed = 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, args.jobs)) as pool:
        futures = [pool.submit(check_case, case) for case in selected]
        for future in concurrent.futures.as_completed(futures):
            case, error = future.result()
            completed += 1
            if error:
                print(f"FAILED {case['name']}\n{error}", file=sys.stderr)
                return 1
            if not args.quiet and (len(selected) <= 200 or completed % 100 == 0 or completed == len(selected)):
                print(f"[{completed}/{len(selected)}] checked")
    shard_note = f" (shard {args.shard})" if args.shard else ""
    print(f"checked {len(selected)} CSP code-generation cases with {args.jobs} jobs{shard_note}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
