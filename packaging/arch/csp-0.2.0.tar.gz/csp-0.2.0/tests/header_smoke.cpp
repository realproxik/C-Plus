#include <cp/stdlib.h>
#include <csxStudio.h>
#include <array.h>
#include <list.h>
#include <map.h>
#include <memory.h>
#include <new.h>
#include <set.h>

int main() {
  const auto parsed = cp::site::parse("http://example.com/docs");
  const cp::net::endpoint endpoint = cp::site::endpoint_for(parsed);
  cp::map<int, int> values{{1, 4}};
  cp::set<int> unique{2, 3, 3};
  cp::list<int> sequence{1, 2};
  cp::append(sequence, 3);
  const auto fixed = cp::make_array(2, 4, 8);
  cp::arena storage;
  int *number = storage.create<int>(7);
  csx::studio::project project{"demo"};
  const auto build = csx::studio::command(project);
  return parsed.host == "example.com" && endpoint.port == 80 &&
                 *cp::find_value(values, 1) == 4 && unique.size() == 2 &&
                 sequence.size() == 3 && fixed[2] == 8 && *number == 7 &&
                 !build.empty()
             ? 0
             : 1;
}
